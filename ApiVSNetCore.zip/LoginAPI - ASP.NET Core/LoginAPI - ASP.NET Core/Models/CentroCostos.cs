﻿namespace LoginAPI___ASP.NET_Core.Models
{
    public class CentroCostos
    {
        public int Codigo { get; set; }
        public string NombreCentroCostos { get; set; }

        public CentroCostos()
        {

        }
    }
}
