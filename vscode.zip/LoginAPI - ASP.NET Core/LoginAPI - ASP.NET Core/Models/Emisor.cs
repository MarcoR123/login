﻿namespace LoginAPI___ASP.NET_Core.Models
{
    public class Emisor
    {
        public int Id { get; set; }
        public string NombreEmisor { get; set; }
        public Emisor()
        {

        }
    }
}
