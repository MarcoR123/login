﻿namespace LoginAPI___ASP.NET_Core.Models
{
    public class LoginResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string Token { get; set; }

        public LoginResponse()
        {
        }
    }
}
