﻿namespace LoginAPI___ASP.NET_Core.Models
{
    public class LoginModel
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }

        public LoginModel()
        {

        }
    }
}
