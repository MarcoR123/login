﻿namespace LoginAPI___ASP.NET_Core.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public Usuario()
        {

        }
    }
}
